This file contains both the attribute and relationship predictions.

The number in file ``1_30_attr.json'' and ``1_30_rel.json'' denotes the start and end frame of the video, please see the annotations/video_clips.txt

For attribute resutls, the prediction is a 2-dim vector, corresponding to annotations/knowledge/attribute_list.txt
For relation results, the prediction is a 6-dim vector, corresponding to annotations/knowledge/relation_list.txt
